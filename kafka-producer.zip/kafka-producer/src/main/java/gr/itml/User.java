package gr.itml;

public class User {

    private int customerId;
    private String customerName;

    public User(){

    }

    public User(int customerId, String customerName) {
        this.customerId = customerId;
        this.customerName = customerName;
    }

    @Override public String toString() {
        return "Customer{" +
                        "customerId=" + customerId +
                        ", customerName='" + customerName + '\'' +
                        '}';
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getCustomerId() {

        return customerId;
    }
}