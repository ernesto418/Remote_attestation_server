package gr.itml;

import java.util.Properties;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONObject;

public class App 
{
    public static void main( String[] args )
    {
        String topic = "infineon-attestation";
        Properties properties=new Properties();
		properties.put("bootstrap.servers", "col1.itml.gr:9093");
		properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.put("security.protocol","SSL");
		properties.put("ssl.truststore.location","/Users/josel/Desktop/InfineonWork/kafka-producers-consumers/java/kafka-producer/src/main/resources/certificates/truststore.jks");
		properties.put("ssl.truststore.password","kafka123");
		properties.put("ssl.keystore.location","/Users/josel/Desktop/InfineonWork/kafka-producers-consumers/java/kafka-producer/src/main/resources/certificates/keystore.jks");
		properties.put("ssl.keystore.password","kafka123");
		properties.put("ssl.key.password","kafka123");
		KafkaProducer<String,String> myProducer= new KafkaProducer<String,String>(properties);
		
		String message;
    	JSONObject item = new JSONObject();
    	item.put("Time", "1/2/2022");
    	item.put("ID", "test");
    	item.put("V_ID", "test8");
    	item.put("Status", false);
    	message = item.toString();
    	
    	//String message2="{\"Status\":true,\"ID\":\"test\",\"V_ID\":\"test1\"}"; //Another test
    	
        try {
			myProducer.send(new  ProducerRecord<String, String>(topic,message));
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			myProducer.close();
		}
    }
}
