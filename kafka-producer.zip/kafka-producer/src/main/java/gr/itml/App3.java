package gr.itml;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class App3 
{
    public static void main( String[] args )
    {
        String topic = "infineon-attestation";
        Properties properties=new Properties();
		properties.put("bootstrap.servers", "col1.itml.gr:9093");
		properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.put("value.serializer",JsonSerializer.class.getName());
		properties.put("security.protocol","SSL");
		properties.put("ssl.truststore.location","/Users/josel/Desktop/InfineonWork/kafka-producers-consumers/java/kafka-producer/src/main/resources/certificates/truststore.jks");
		properties.put("ssl.truststore.password","kafka123");
		properties.put("ssl.keystore.location","/Users/josel/Desktop/InfineonWork/kafka-producers-consumers/java/kafka-producer/src/main/resources/certificates/keystore.jks");
		properties.put("ssl.keystore.password","kafka123");
		properties.put("ssl.key.password","kafka123");
		ObjectMapper objectMapper = new ObjectMapper();
		User customer = new User(1, "jose");
		KafkaProducer<String,JsonNode> kafkaProducer= new KafkaProducer<String,JsonNode>(properties);;
		JsonNode jsonNode = objectMapper.valueToTree(customer);
        ProducerRecord<String,JsonNode> producerRecord = new ProducerRecord<String, JsonNode>(topic,jsonNode);
        try {
            RecordMetadata recordMetadata = kafkaProducer.send(producerRecord).get();
            System.out.println(recordMetadata);
            kafkaProducer.close();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
        	
        }
    }
}
